-- MySQL dump 10.13  Distrib 5.7.15, for Linux (x86_64)
--
-- Host: localhost    Database: noveldb
-- ------------------------------------------------------
-- Server version	5.7.15

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `save`
--

DROP TABLE IF EXISTS `save`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `save` (
  `dataid` int(11) DEFAULT NULL,
  `playername` varchar(64) DEFAULT NULL,
  `text` varchar(255) DEFAULT NULL,
  `char1` varchar(256) DEFAULT NULL,
  `char2` varchar(256) DEFAULT NULL,
  `bg` varchar(256) DEFAULT NULL,
  `bgm` varchar(256) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `save`
--

LOCK TABLES `save` WRITE;
/*!40000 ALTER TABLE `save` DISABLE KEYS */;
INSERT INTO `save` VALUES (0,'野獣先輩','ーー時は20XX年(意外と近い)','image/char/man.png','','image/bg/seikimathu.png','sound/bgm/seikimathu.ogg');
/*!40000 ALTER TABLE `save` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `saveData`
--

DROP TABLE IF EXISTS `saveData`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `saveData` (
  `dataID` int(11) DEFAULT NULL,
  `playerName` varchar(64) DEFAULT NULL,
  `sceneID` int(11) DEFAULT NULL,
  `text` varchar(255) DEFAULT NULL,
  `char1` varchar(256) DEFAULT NULL,
  `char2` varchar(256) DEFAULT NULL,
  `bg` varchar(256) DEFAULT NULL,
  `bgm` varchar(256) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `saveData`
--

LOCK TABLES `saveData` WRITE;
/*!40000 ALTER TABLE `saveData` DISABLE KEYS */;
INSERT INTO `saveData` VALUES (1,'野獣先輩',0,'ーー時は20XX年(意外と近い)','image/char/man.png','','image/bg/seikimathu.png','sound/bgm/seikimathu.ogg'),(2,'',0,NULL,'','','',''),(3,'',0,NULL,'','','',''),(4,'',0,NULL,'','','','');
/*!40000 ALTER TABLE `saveData` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `scenario`
--

DROP TABLE IF EXISTS `scenario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `scenario` (
  `id` int(11) DEFAULT NULL,
  `command` varchar(8) DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL,
  `nextid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `scenario`
--

LOCK TABLES `scenario` WRITE;
/*!40000 ALTER TABLE `scenario` DISABLE KEYS */;
INSERT INTO `scenario` VALUES (0,'TXT','ーー時は20XX年(意外と近い)',1),(1,'TXT','世界は核の炎に包まれていないが、世界は世紀末となっていた・・・',2),(2,'TXT','草木は朽ち果て、川も干上がり、',3),(3,'TXT','人々は飢餓に苦しみ、子も産まれず、',4),(4,'TXT','希望に満ち溢れた未来はそこにはなかった。',5),(5,'TXT','しかし、そのような世界にもやベーヤツはいる。',6),(6,'TXT','正に「ヒャッハー！」な奴らである(説明省略)。',7),(7,'TXT','だが、絶望に満ち足りた世界にも鈍光があるのだ。',8),(8,'TXT','「忘れ去られた栄光」というものが・・・',9),(9,'TXT','そう、彼の者の名は・・・',10),(10,'TXT','名は・・・',11),(11,'TXT','・・・',12),(12,'TXT','・・・',13),(13,'BGM','',14),(14,'TXT','アレ？なんでしたっけ・・・？',15),(15,'TXT','あ！そうだ、あれね。あれ。',16),(16,'TXT','いや〜完全に忘れちゃうところだったよ。なにせ「忘れ去られた栄光」だからね！',17),(17,'TXT','あ、ここカットしておいてね。あとBGM再生お願い。',18),(18,'BGM','sound/bgm/seikimathu.ogg',19),(19,'TXT','そう、彼の者の名は##NAME##！',20),(20,'TXT','「伝説の拳聖」の異名を轟かせた剛拳にして俊敏',21),(21,'TXT','名立たる舞踏家・武術家が100人襲いかかっても、0.5秒で瞬殺するその業',22),(22,'TXT','正に生ける伝説・・・',23),(23,'CHAR2','image/char/bba.png',24),(24,'TXT','のBBAである。',25),(25,'BGM','sound/bgm/bba.ogg',26),(26,'TXT','ホッホッホホ。最近耳が遠くてね。体も最近鈍ってしまって、手押し車がないと歩けもしないわい。',27),(27,'TXT','ところでそこの馴鹿の服装をしたお方。',28),(28,'TXT','先程このおばぁの名前を忘れていたそうな・・・',29),(29,'TXT','・・・',30),(30,'SE','sound/se/punch.ogg',31),(31,'CHAR1','',32),(32,'BGM','sound/bgm/dead.ogg',33),(33,'BG','image/bg/dead.png',34),(34,'TXT','今度から人の名前はしっかり覚えておくんだよ。',35),(35,'TXT','じゃないと・・・ホッホッホッホ。',36),(36,'TXT','「伝説の拳聖」の異名を轟かせた##NAME##の通った道には、',37),(37,'TXT','肉塊や塵が散乱とし、灰す暗く重重しい空間となっていた逸話も残っている。',38),(38,'TXT','彼女こそがこの世を阿鼻叫喚尽きぬ地獄すら生温いモノと変えたのである。',39),(39,'TXT','END',40),(40,'END','',40);
/*!40000 ALTER TABLE `scenario` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-12-31 23:00:08
